## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(WNNRina)

# Generate a synthetic seasonal signal
set.seed(123)
history <- sin(seq(0, 100, length.out = 2000)) + rnorm(2000, sd = 0.1)

# Forecast the next 96 points (i.e. one day at 15-min intervals)
# window_size: length of the pattern to match
# k: number of neighbors to consider
forecast <- predict_wnn(train_y = history, window_size = 96, k = 5, forecast_h = 96)

plot(forecast, type = "l", col = "blue", main = "WNN Forecast Example", ylab = "Value")

## ----fig.width=7, fig.height=4------------------------------------------------
# Example of how the comparison looks
actuals <- sin(seq(0, pi, length.out = 96)) + 10
xgb_preds <- actuals + rnorm(96, sd = 0.05)
wnn_preds <- actuals + rnorm(96, sd = 0.2)

plot(actuals, type="l", lwd=2, main="XGBoost vs WNN")
lines(xgb_preds, col="red", lty=2)
lines(wnn_preds, col="blue", lty=3)
legend("topright", legend=c("Actual", "XGBoost", "WNN"), 
       col=c("black", "red", "blue"), lty=1:3)

